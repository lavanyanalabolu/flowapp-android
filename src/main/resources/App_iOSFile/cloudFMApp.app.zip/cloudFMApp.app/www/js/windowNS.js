window.APP = {};

window.viewConstructors = {};

window.globalTpl = {};

window.App = {
	Views: {},
	Router: {},
	Subrouters: {},
	SubrouteConstructors: {},
	SlideConstructors: {}
};
